To run part 1 of the assignment run the A2Part1 file, to run the part of the assignment run A2Part2.
When running part 2 if you run the eagle jpg it takes roughly 10 minutes on my computer, if you run the dog jpg it takes significantly less time because it is a smaller image.
Another thing to note when running part 2 is that the filename must be the beginning filename. For reference see the example run in ExampleResults.txt.

If any further information regarding the code is required please inquiry me at dh15pd@brocku.ca.