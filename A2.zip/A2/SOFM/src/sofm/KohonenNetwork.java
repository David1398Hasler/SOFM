package sofm;

import java.io.IOException;
import java.util.ArrayList;

/**
 * This class is a SOFM that is generalized for any number of input weights.
 *
 * @author David Hasler - 6041321
 * @email dh15pd@brocku.ca
 * @date March 31th, 2021
 **/
public class KohonenNetwork {
    private Neuron[][] network;
    private final ArrayList inputVector;
    
    /**
     * Creates a version of the network.
     *
     * @param n - uses network for input
     * @param i - input vector for training
     */
    public KohonenNetwork(Neuron[][] n, ArrayList i){
        network = n;
        inputVector = i;
    }
    
    /**
     * Returns the network.
     *
     * @return network
     */
    public Neuron[][] getNetwork(){
        return network;
    }
    
    /**
     * Creates a new network for the colour experiment.
     *
     * @param width
     * @param height
     */
    public void newNetwork(int width, int height) {
        network = new Neuron[width][height];
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                network[x][y] = new Neuron(x, y);
            }
        }
    }
    
    /**
     * Creates a generalized network that works with any weight array size.
     *
     * @param width
     * @param height
     * @param size
     */
    public void newNetwork(int width, int height, int size) {
        network = new Neuron[width][height];
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                network[x][y] = new Neuron(x, y, size);
            }
        }
    }
    
    /**
     * getInputVector returns a random input vector from the Colors or any input vector.
     *
     * @param inputVector
     * @return Neuron v
     */
    public Neuron getColorInputVector(ArrayList inputVector) {
        int randomw = (int) (Math.random() * inputVector.size());
        return (Neuron) inputVector.get(randomw);
    }
    
    /**
     * Gets the BMU of the network for the neuron v. Compares Euclidean distances until
     * best matching unit is found and returns neuron.
     *
     * @param width
     * @param height
     * @param v
     * @param weightsSize
     * @return neuron BMU
     */
    public Neuron getBMU(int width, int height, Neuron v, int weightsSize){
        Neuron BMU = null;
        //Find BMU for input vector
            for (int x = 0; x < width; x++) {
                for (int y = 0; y < height; y++) {
                    if (BMU == null) {
                        BMU = new Neuron(network[x][y].getxPos(), network[x][y].getyPos(), weightsSize);
                        for(int i = 0; i < weightsSize; i++){
                            BMU.setWeights(network[x][y].getWeights(i), i);
                        }
                    } else if (network[x][y].getEuclideanDistance(v) < BMU.getEuclideanDistance(v)) {
                        BMU = new Neuron(network[x][y].getxPos(), network[x][y].getyPos(), weightsSize);
                        for(int i = 0; i < weightsSize; i++){
                            BMU.setWeights(network[x][y].getWeights(i), i);
                        }
                    }
                }
            }
            return BMU;
    }
    
    /**
     * If the neuron distance is within the neighborhood radius then update its weight.
     *
     * @param width
     * @param height
     * @param BMU
     * @param v
     * @param neighbourhoodRadius
     * @param lrate
     */
    public void updateWeights(int width, int height, Neuron BMU, Neuron v, double neighbourhoodRadius, double lrate){
        for (int x = 0; x < width; x++) {
                for (int y = 0; y < height; y++) {
                    double distSquared = BMU.getDistanceTo(network[x][y]);
                    if (distSquared <= neighbourhoodRadius * neighbourhoodRadius / 2) {
                        double distFalloff = Math.exp(-(distSquared) / (2 * (neighbourhoodRadius * neighbourhoodRadius)));
                        network[x][y].adjustWeights(lrate, v, distFalloff);
                    }
                }
            }
    }
    
    /**
     * The main function of the SOFM it runs using the given network parameters.
     * For each iteration it takes an input vector, it then finds the BMU for the input
     * vector. Once found the network updates weights within the neighborhood radius and
     * keeps running until all input vectors are done
     *
     * @param iteration
     * @param numEpochs
     * @param numIterations
     * @param initLearnrate
     * @param nbhdRadius
     * @param width
     * @param height
     * @param size
     * @throws IOException
     * @throws InterruptedException
     */
    public void runColorSOFM(int iteration, int numEpochs, int numIterations, double initLearnrate, int nbhdRadius, int width, int height, int size) throws IOException, InterruptedException {
        Neuron BMU = null;
        // Add colors for input vector training
        for (int i = 0; i < numIterations; i++) {
            //get random input vector
            Neuron v = getColorInputVector(inputVector);
            BMU = getBMU(width, height, v, size);
            double timeConstant = numEpochs / Math.log(nbhdRadius);
            double neighbourhoodRadius = nbhdRadius * Math.exp(-(double) iteration / timeConstant);
            double lrate = initLearnrate * Math.exp(-(double) iteration / timeConstant);
            //Update weights of BMU neighbourhood
            updateWeights(width, height, BMU, v, neighbourhoodRadius, lrate);
        }
    }
}
