package sofm;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;

/**
 * This class makes an image frame from the image of the size and x and y, and 
 * makes it usable as a neuron.
 *
 * @author David Hasler - 6041321
 * @email dh15pd@brocku.ca
 * @date March 31th, 2021
 */
public class ImageFrame {

    private final Neuron frame;

    /**
     * Creates an ImageFrame out of an image and uses the x and y points and width to create a smaller
     * image out of the image. Which is then represented as a neuron for input.
     *
     * @param img - the image to get frame from
     * @param startX - starting x point in image
     * @param startY - starting y point in image
     * @param width - width of the frame
     * @throws IOException
     */
    public ImageFrame(BufferedImage img, int startX, int startY, int width) throws IOException {
        frame = new Neuron(startX, startY, width * width);
        Graphics g = img.getGraphics();
        for (int x = startX; x < width + startX; x++) {
            for (int y = startY; y < width + startY; y++) {
                if (x < img.getWidth() && y < img.getHeight()) {
                    int pixel = img.getRGB(x, y);
                    //Creating a Color object from pixel value
                    Color color = new Color(pixel, true);
                    //Retrieving the R G B values
                    int red = color.getRed();
                    int green = color.getGreen();
                    int blue = color.getBlue();
                    frame.setWeights(red/255.0, (x - startX) * width + (y - startY));
                }
            }
        }
    }

    /**
     *
     * @return the neuron representation of frame
     */
    public Neuron getFrame() {
        return frame;
    }

}
