package sofm;

/**
 * This is a neuron that is used in the SOFM as part of the network.
 *
 * @author David Hasler - 6041321
 * @email dh15pd@brocku.ca
 * @date March 31th, 2021
 **/
public class Neuron {

    private double r = 0;
    private double g = 0;
    private double b = 0;
    private int xPos;
    private int yPos;
    private double weights[] = new double[3];

    /**
     * Used to create a colour SOFM, uses 3 weights only for RGB.
     *
     * @param y
     * @param x
     * @param size
     */
    public Neuron(int y, int x) {
        yPos = y;
        xPos = x;

        r = Math.random();
        g = Math.random();
        b = Math.random();

        weights[0] = r;
        weights[1] = g;
        weights[2] = b;
    }

    /**
     * Used to create any SOFM, weights are not optimized for colours.
     *
     * @param y
     * @param x
     * @param size
     */
    public Neuron(int y, int x, int size) {
        yPos = y;
        xPos = x;

        weights = new double[size];
    }

    /**
     * Gets the weight of the neuron at the position.
     *
     * @param i - weight at
     * @return the weight
     */
    public double getWeights(int i) {
        return weights[i];
    }

    /**
     * Sets a new weight at the desired position.
     *
     * @param val - change weight to
     * @param i - weight position
     */
    public void setWeights(double val, int i) {
        weights[i] = val;
    }

    /**
     * Adjusts the weights because neuron is within the neighborhood radius.
     *
     * @param lrate
     * @param v
     * @param distFalloff
     */
    public void adjustWeights(double lrate, Neuron v, double distFalloff) {
        for (int i = 0; i < weights.length; i++) {
            weights[i] += distFalloff * lrate * (v.getWeights(i) - weights[i]);
            if (weights[i] < 0) {
                weights[i] = 0;
            } else if (weights[i] > 1) {
                weights[i] = 1;
            }
        }
    }

    /**
     *
     * @return the neurons x position in network.
     */
    public int getxPos() {
        return xPos;
    }

    /**
     *
     * @return the neurons y position in network.
     */
    public int getyPos() {
        return yPos;
    }

    /**
     *
     * @param x - new x position
     */
    public void setxPos(int x) {
        xPos = x;
    }

    /**
     *
     * @param y - new y position
     */
    public void setyPos(int y) {
        yPos = y;
    }

    /**
     * Gets the distance to the neuron in the network and is squared.
     *
     * @param n - neuron
     * @return the squared distance to neuron n
     */
    public double getDistanceTo(Neuron n) {
        double dx, dy;
        dy = yPos - n.getyPos();
        dy *= dy;
        dx = xPos - n.getxPos();
        dx *= dx;
        return dy + dx;
    }

    /**
     * Used in SOFM to return the euclidean distance and find the BMU in network.
     *
     * @param v - neuron 
     * @return the euclidean distance for this neuron against another neuron
     */
    public double getEuclideanDistance(Neuron v) {
        double distance = 0.0;
        for (int i = 0; i < weights.length; i++) {
            distance += (v.getWeights(i) - weights[i]) * (v.getWeights(i) - weights[i]); // distance adds up (Vi - Wi)^2
        }
        return Math.sqrt(distance); // distance = square root(distance)
    }
}
