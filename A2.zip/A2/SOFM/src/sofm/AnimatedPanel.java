package sofm;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import javax.swing.JPanel;

/**
 * This class creates an animated JPanel that is used for the A2Part1 animation.
 *
 * @author David Hasler - 6041321
 * @email dh15pd@brocku.ca
 * @date March 31th, 2021
 **/

public class AnimatedPanel extends JPanel{
    private BufferedImage img;
    
    /**
     * Creates a jpanel used for animation
     *
     * @param i image that is initialized on panel
     */
    public AnimatedPanel(BufferedImage i){
        super();
        img = i;
    }
    
    /**
     * Sets the new image for the next animation.
     *
     * @param i is a buffered image that is rendered on the jpanel
     */
    public void setImage(BufferedImage i){
        img = i;
    }
    
    @Override
    public void paint(Graphics g){
        super.paint(g);
        g.drawImage(img, 650, 300, null);
    }
}
