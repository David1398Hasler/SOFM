package A2Part2;

import java.awt.Color;
import sofm.*;
import java.awt.image.BufferedImage;
import static java.awt.image.BufferedImage.TYPE_INT_RGB;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

/**
 * This is the second part of the assignment. When you run this file it will
 * get input from the console and an example of a run is included. 
 * 
 * @author David Hasler - 6041321
 * @email dh15pd@brocku.ca
 * @date March 31th, 2021
 */
public class A2Part2 {

    public static Neuron[][] network;

    public static void main(String[] args) {
        try {
            int numEpochs, nbhdRadius, networkWidth, networkHeight, frameWidth;
            double initLearnrate;
            String fileName;
            
            Scanner sc = new Scanner(System.in);
            System.out.println("Filename to compress, just the first part, example dog instead of dog.jpg: ");
            fileName = sc.nextLine();
            System.out.println("Enter learning rate: ");
            initLearnrate = sc.nextDouble();
            System.out.println("Enter number of epochs: ");
            numEpochs = sc.nextInt();
            System.out.println("Enter neighborhood radius: ");
            nbhdRadius = sc.nextInt();
            System.out.println("Enter network width: ");
            networkWidth = sc.nextInt();
            networkHeight = networkWidth;
            System.out.println("Enter frame width: ");
            frameWidth = sc.nextInt();
            
            try {
                ImageFrame frame;
                ArrayList framesToTrain = new ArrayList();
                BufferedImage img = ImageIO.read(new File(fileName + ".jpg"));
                for (int x = 0; x < img.getWidth(); x++) {
                    for (int y = 0; y < img.getHeight(); y++) {
                        // If the x and y divided by the width with remainder = 0, then add a frame for the piece
                        if ((x + 1) % frameWidth == 0 && (y + 1) % frameWidth == 0) {
                            frame = new ImageFrame(img, x, y, frameWidth);
                            framesToTrain.add(frame.getFrame());
                        }
                    }
                }
                //Begin training network on frames
                KohonenNetwork k = new KohonenNetwork(null, framesToTrain);
                k.newNetwork(networkWidth, networkHeight, frameWidth * frameWidth);
                for (int iteration = 0; iteration < numEpochs; iteration++) {
                    k.runColorSOFM(iteration, numEpochs, framesToTrain.size(), initLearnrate, nbhdRadius, networkWidth, networkHeight, frameWidth * frameWidth);
                }
                //for each frame in image:
                //  find best matching frame in network with frame in image and mark with byte in indices ArrayList
                ArrayList indexes = new ArrayList();
                for (Object framesToTrain1 : framesToTrain) {
                    Neuron tempFrame = k.getBMU(networkWidth, networkHeight, (Neuron) framesToTrain1, frameWidth * frameWidth);
                    int index = tempFrame.getxPos() * networkWidth + tempFrame.getyPos();
                    indexes.add(index);
                }
                
                FileOutputStream out = new FileOutputStream(fileName + "Codebook.txt");
                //write width and height of image measured in frames
                int tempInt = img.getWidth() / frameWidth;
                byte tempByte;
                
                out.write(tempInt);
                tempInt = img.getHeight() / frameWidth;
                out.write(tempInt);
                //write width and height of frame
                tempByte = (byte) frameWidth;
                out.write(tempByte);
                //write network width and height
                tempByte = (byte) networkWidth;
                out.write(tempByte);
                //write codebook
                for (int x = 0; x < networkWidth; x++) {
                    for (int y = 0; y < networkHeight; y++) {
                        for (int i = 0; i < frameWidth * frameWidth; i++) {
                            int codeWeights = (int) (k.getNetwork()[x][y].getWeights(i) * 255);
                            out.write(codeWeights);
                        }
                    }
                }
                //write codebook indices
                for (Object indexe : indexes) {
                    int index = (int) indexe;
                    tempByte = (byte) (index);
                    out.write(tempByte);
                }
                out.close();
                FileInputStream in = new FileInputStream(fileName + "Codebook.txt");
                int imageWidth = 0;
                int imageHeight = 0;
                int frameSize = 0;
                int networkSize = 0;
                int a = in.read();
                if (a != 1) {
                    imageWidth = a;
                }
                a = in.read();
                if (a != 1) {
                    imageHeight = a;
                }
                a = in.read();
                if (a != 1) {
                    frameSize = a;
                }
                a = in.read();
                if (a != 1) {
                    networkSize = a;
                }
                ArrayList codeBook = new ArrayList();
                for (int x = 0; x < networkSize * networkSize; x++) {
                    int[] codeWeights = new int[frameSize * frameSize];
                    for (int i = 0; i < frameSize * frameSize; i++) {
                        a = in.read();
                        if (a != 1) {
                            codeWeights[i] = a;
                        }
                    }
                    codeBook.add(codeWeights);
                    
                }
                
                a = in.read();
                ArrayList ind = new ArrayList();
                while (a != -1) {
                    int tempIndex = (int) a;
                    ind.add(tempIndex);
                    a = in.read();
                }
                
                //Recreate Image using compressed file format
                BufferedImage image = new BufferedImage(imageWidth * frameSize, imageHeight * frameSize, TYPE_INT_RGB);
                int x = 0;
                int y = 0;
                for (Object ind1 : ind) {
                    int index = (int) ind1;
                    int[] codesForIndex = (int[]) codeBook.get(index);
                    int currentWeightCode = 0;
                    for (int starty = y; starty < y + frameSize; starty++) {
                        for (int startx = x; startx < x + frameSize; startx++) {
                            int tempColour = codesForIndex[currentWeightCode];
                            Color c = new Color(tempColour, tempColour, tempColour);
                            image.setRGB(startx, starty, c.getRGB());
                            currentWeightCode++;
                        }
                    }
                    y += frameSize;
                    if (y >= frameSize * imageHeight) {
                        y = 0;
                        x += frameSize;
                        if (x >= frameSize * imageWidth) {
                            break;
                        }
                    }
                }
                
                File f = new File(fileName + "Compressed.jpg");
                ImageIO.write(image, "jpg", f);
                in.close();
                
            } catch (FileNotFoundException ex) {
                Logger.getLogger(A2Part2.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException | InterruptedException ex) {
                Logger.getLogger(A2Part2.class.getName()).log(Level.SEVERE, null, ex);
            }
            System.out.println("Codebook is in " + fileName + "Codebook.txt");
            System.out.println("Output file is in " + fileName + "Compressed.jpg");
            
            // next get the sum of differences in pixel color.
            BufferedImage originalImage = ImageIO.read(new File(fileName + ".jpg"));
            BufferedImage compressedImage = ImageIO.read(new File(fileName + "Compressed.jpg"));
            double sum = 0;
            for (int x = 0; x < compressedImage.getWidth(); x++) {
                for (int y = 0; y < compressedImage.getHeight(); y++) {
                    sum += Math.abs(originalImage.getRGB(x, y) - compressedImage.getRGB(x, y));
                }
            }
            System.out.println("The sum of differences in the original versus the compressed image: " + sum);
        } catch (IOException ex) {
            Logger.getLogger(A2Part2.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
