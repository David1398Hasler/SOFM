/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package a2part2;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.awt.Color;
import java.awt.image.BufferedImage;
import static java.awt.image.BufferedImage.TYPE_INT_RGB;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

/**
 *
 * @author David
 */
public class A2Part2 {

    public static Neuron[][] network;

    public static void buildImage(int width, int height) throws IOException {
        BufferedImage img = new BufferedImage(width, height, TYPE_INT_RGB);
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                Color c = new Color(1);
                //Setting new Color object to the image
                img.setRGB(x, y, c.getRGB());
            }
        }
        File f = new File("transformer1.jpg");
        ImageIO.write(img, "jpg", f);
    }

    public static void main(String[] args) {
        try {
            ImageFrame frame;
            ArrayList framesToTrain = new ArrayList();
            BufferedImage img = ImageIO.read(new File("transformer.jpg"));
            int width = 16;
            for (int x = 0; x < img.getWidth(); x++) {
                for (int y = 0; y < img.getHeight(); y++) {
                    // If the x and y divided by the width with remainder = 0, then add a frame for the piece
                    if ((x + 1) % width == 0 && (y + 1) % width == 0) {
                        frame = new ImageFrame(img, x, y, width);
                        framesToTrain.add(frame.getFrame());
                    }
                }
            }
            KohonenNetwork k = new KohonenNetwork(null, framesToTrain);
            int numEpochs, nbhdRadius, networkWidth, networkHeight;
            double initLearnrate = 0.3;
            nbhdRadius = 12;
            numEpochs = 300;
            networkWidth = 16;
            networkHeight = 16;

            network = new Neuron[networkWidth][networkHeight];
            for (int x = 0; x < networkWidth; x++) {
                for (int y = 0; y < networkHeight; y++) {
                    network[x][y] = new Neuron(x, y, width*width);
                }
            }
            network = k.getNetwork();
            for (int iteration = 0; iteration < numEpochs; iteration++) {
                k.runColorSOFM(iteration, numEpochs, framesToTrain.size(), initLearnrate, nbhdRadius, networkWidth, networkHeight, width*width);
            }
            network = k.getNetwork();
            //for each frame in image:
            //  find best matching frame in network with frame in image and mark with byte in indices ArrayList
            ArrayList indexes = new ArrayList();
            for (int x = 0; x < framesToTrain.size(); x++) {
                Neuron tempFrame = k.getBMU(networkWidth, networkHeight, (Neuron) framesToTrain.get(x), width*width);
                int index = tempFrame.getxPos() * networkWidth + tempFrame.getyPos();
                indexes.add(index);
            }
            System.out.println("Done!");

        } catch (IOException | InterruptedException ex) {
            Logger.getLogger(A2Part2.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

