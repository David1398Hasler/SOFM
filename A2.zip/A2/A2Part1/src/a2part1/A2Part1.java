/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package a2part1;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.event.*;
import static java.awt.image.BufferedImage.TYPE_INT_RGB;
import java.util.logging.Level;
import java.util.logging.Logger;
import static javax.swing.JFrame.EXIT_ON_CLOSE;

/**
 *
 * @author David
 */
public class A2Part1 extends JFrame {

    public static Neuron[][] network = null;
    public static ArrayList inputVector = null;

    // GUI INTERFACE BEGIN
    public A2Part1(KohonenNetwork k) throws IOException {
        setTitle("Kohonen network");
        setSize(1500, 800); // Changes the size of the frame for the output
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        BorderLayout layout = new BorderLayout();
        this.setLayout(layout);
        //Changes the width and height of the colour map
        int w = 200;
        int h = w;

        k.newNetwork(w, h);
        network = k.getNetwork();
        buildImage(0, w, h);
        BufferedImage img = ImageIO.read(new File("epoch" + 0 + ".jpg"));
        AnimatedPanel a = new AnimatedPanel(200, 200, img);

        JLabel numEpochsperAnimationLabel = new JLabel("Number of Epochs in animation: ");
        JLabel numEpochsLabel = new JLabel("Number of Epochs: ");
        JLabel learnRateLabel = new JLabel("Learning Rate: ");
        JLabel nbhdLabel = new JLabel("Neighboorhood Radius: ");
        JLabel widthLabel = new JLabel("Width: " + w);
        JLabel heightLabel = new JLabel("Height: " + h);

        JTextField nextEpochsTextField = new JTextField("5", 10);
        JTextField numEpochsTextField = new JTextField("30", 10);
        JTextField learnRateTextField = new JTextField("0.1", 10);
        JTextField nbhdTextField = new JTextField("150", 10);

        JButton trainButton = new JButton("Train Network");
        JButton newNetworkButton = new JButton("New Network");

        trainButton.setActionCommand("Train Network");
        newNetworkButton.setActionCommand("New Network");

        trainButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.out.println("Training");
                if (numEpochsTextField.getText().isEmpty() || learnRateTextField.getText().isEmpty() || nextEpochsTextField.getText().isEmpty()) {
                    System.out.println("You have entered an empty field");
                } else {
                    int iteration = 0;
                    int totalEpochs = Integer.parseInt(numEpochsTextField.getText());
                    double lrate = Double.parseDouble(learnRateTextField.getText());
                    int epochsPerAnimation = Integer.parseInt(nextEpochsTextField.getText());
                    int nbhdRadius = Integer.parseInt(nbhdTextField.getText());
                    for (int x = 1; x <= totalEpochs; x++) {
                        try {
                            k.runColorSOFM(iteration, totalEpochs, inputVector.size(), lrate, nbhdRadius, w, h, 3);
                            iteration++;
                            if(x%epochsPerAnimation == 0){
                            network = k.getNetwork();
                            buildImage(0, w, h);
                            a.setImage(ImageIO.read(new File("epoch" + 0 + ".jpg")));
                            a.paintImmediately(a.getX(), a.getY(), a.getWidth(), a.getHeight());
                            }
                        } catch (IOException ex) {
                            Logger.getLogger(A2Part1.class.getName()).log(Level.SEVERE, null, ex);
                        } catch (InterruptedException ex) {
                            Logger.getLogger(A2Part1.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
            }
        }
        );
        newNetworkButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                try {
                    System.out.println("New Network");
                    k.newNetwork(w, h);
                    network = k.getNetwork();
                    buildImage(0, w, h);
                    a.setImage(ImageIO.read(new File("epoch" + 0 + ".jpg")));
                    repaint();
                } catch (IOException ex) {
                    Logger.getLogger(A2Part1.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });

        JPanel p1 = new JPanel();
        p1.setSize(400, 400);
        p1.add(trainButton);
        p1.add(newNetworkButton);
        p1.add(numEpochsLabel);
        p1.add(numEpochsTextField);
        p1.add(numEpochsperAnimationLabel);
        p1.add(nextEpochsTextField);
        p1.add(learnRateLabel);
        p1.add(learnRateTextField);
        p1.add(nbhdLabel);
        p1.add(nbhdTextField);
        p1.add(widthLabel);
        p1.add(heightLabel);
        this.add(a, BorderLayout.CENTER);
        this.add(p1, BorderLayout.SOUTH);
    }
    // GUI INTERFACE END

    public static void buildImage(int j, int width, int height) throws IOException {
        BufferedImage img = new BufferedImage(width, height, TYPE_INT_RGB);
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                int red = (int) (network[x][y].getWeights(0) * 255);
                int green = (int) (network[x][y].getWeights(1) * 255);
                int blue = (int) (network[x][y].getWeights(2) * 255);
                Color c = new Color(red, green, blue);
                //Setting new Color object to the image
                img.setRGB(x, y, c.getRGB());
            }
        }
        File f = new File("epoch" + j + ".jpg");
        ImageIO.write(img, "jpg", f);
    }

    

    // NETWORK CODE END
    public static void main(String[] args) throws IOException {
        int numIterations = 75;
        inputVector = new ArrayList();
        for (int i = 0; i < numIterations; i++) {
            float r, g, b;
            r = (float) Math.random();
            g = (float) Math.random();
            b = (float) Math.random();
            Neuron v = new Neuron(0, 0);
            v.setWeights(r, 0);
            v.setWeights(g, 1);
            v.setWeights(b, 2);
            inputVector.add(v);
        }
        KohonenNetwork k = new KohonenNetwork(network, inputVector);
        A2Part1 ex = new A2Part1(k);
        ex.setVisible(true);

    }
}
